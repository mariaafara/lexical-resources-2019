from bs4 import BeautifulSoup
from collections import defaultdict
import csv
import pandas as pd
import re

def yield_articles(filename):
    """
    Reads the Glawi XML, and produces a sequence of "article" elements as string
    """
    with open(filename) as istr:
        # clean data
        lines = map(str.strip, istr)
        # declare accumulator variable
        article = []
        for line in lines:
            # new element discovered
            if line == "<article>":
                # reinitialize accumulator
                article = []
            # add line to accumulator
            article.append(line)
            # end of current discovered element 
            if line == "</article>":
                # convert accumulator to string, produce element
                yield "\n".join(article)

def yield_title_pos_defs(article_str, pos_set={"nom"}):
    """
    Takes an "article" element string, and converts it into a sequence of triples
    containing title (ie. definiendum), POS and text (ie. associated definientia)
    """
    # create object representation of XML data
    soup = BeautifulSoup(article_str, "lxml")
    # extract text content of "title" element 
    title = soup.title.get_text()
    # flag whether some POS are restricted
    pos_declared = len(pos_set) != 0
    # iterate over "pos" XML children elements
    for pos_soup in soup.find_all("pos"):
        # verify POS tag matches restrictions
        if pos_declared:
            pos_type = pos_soup["type"].strip()
            if not pos_type in pos_set:
                continue
        # iterate over "gloss" XML children elements
        for gloss_soup in pos_soup.find_all("gloss"):
            # iterate over "txt" XML children elements
            for txt_soup in gloss_soup.find_all("txt"):
                # format
                text = txt_soup.get_text()
                if text:
                   yield title, pos_type, text

def make_csv(infile, outfile, pos_set={"nom"}):
    """
    Converts the XML into a handier CSV format
    """
    with open(outfile, "w") as ostr:
        writer = csv.writer(ostr)
        data = (
            (title, pos_type, text)
            for article_str in yield_articles(infile)
            for title, pos_type, text in yield_title_pos_defs(article_str, pos_set)
        )
        for title, pos_type, text in data:
            writer.writerow((title, pos_type, text))

def first_word_of(raw_string):
    """
    Question 1 of Exercise 1.
    Takes a word and returns the actual first word.
    """
    pass

def build_graph(csv_filename):
    """
    Question 2 of Exercise 1.
    Takes a CSV filename, and computes the dictionary graph at step 0
    """
    pass
    
def cycle_graph(graph, seeds):
    """
    Question 3 of Exercise 1. 
    Given a set of seed words `seeds`, finds all their hyponyms in the dictionary
    represented by the graph `graph`. Returns this lexicon afterwards.
    """
    pass
    
def save_lexicon(mined_lexicon, csv_file, filename):
    """
    Question 4 of Exercise 1.
    Given a lexicon, concatenates the information with the CSV data and saves it 
    to a new location.
    """
    pass

if __name__ == "__main__":
    import argparse
    import sys
    parser = argparse.ArgumentParser(description="Graph-mining in GLAWI")
    parser.add_argument("--glawi_file", type=str,
        help="""path to GLAWI XML file.
    If both GLAWI and CSV files are set, the CSV file will be overwritten.""")
    parser.add_argument("--csv_file", type=str,
        help="""path to preparsed CSV file.
    If both GLAWI and CSV files are set, the CSV file will be overwritten.""")
    parser.add_argument("--seeds", type=str, nargs="+", required=True,
        help="Seeds to start up graph-cycling")
    parser.add_argument("--pos", type=str, nargs="+", default=["nom"],
        help="POS set to restrict GLAWI preparsing")
    parser.add_argument("--seeds_file", type=str, default=""
        help="filename for saving extracted seeds.")
    args = parser.parse_args()
    
    # assert you have access to data (XML or CSV format)
    if not (args.glawi_file or args.csv_file):
        sys.exit(__file__ + ": error: either GLAWI or CSV file must be given.")

    # if no CSV file was given, assume it's to be computed from the XML
    csv_file = args.csv_file or "glawi_extracted.csv"
    if args.glawi_file:
        make_csv(args.glawi_file, csv_file, pos_set=args.pos)
        
    # below is the actual lexicon mining
    graph = build_graph(csv_file)
    lexicon = cycle_graph(graph, set(args.seeds))
    save_lexicon(lexicon, csv_file, args.seeds_file)
    
